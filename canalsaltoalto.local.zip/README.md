# Checkout
- Pendente integrar o Tokenize;
- Funcionar o pagamento;








ak_live_Z0vJOVrB36Q5mWHoAIDQnLxlbyREKG










# Routes

/ - Home page to site

/app - Área de membros




## Notices
/app/notices - List all notices
/app/notices/create - Create a notice page
/app/notices/:id - Read a notice page

## Events
/app/events
/app/events/create
/app/events/:id

## Club
/app/club
/app/club/create

## Contents
/app/contents - List all contents
/app/contents/create - Create a new content
/app/contents/:id - Read a content

## Companies
/app/companies/ - List all companies
/app/companies/create - Create a new company
/app/companies/:id - Show informations about some company
/app/companies/:id/edit - Edit a company

## Members
/app/members/ - List all members
/app/members/:id - Show informations about some member
/app/members/me





# À Implementar/Corrigir
- A função de message no Javascript está se repetindo em múltiplos arquivos;
- Criar uma rota somente para autenticação;